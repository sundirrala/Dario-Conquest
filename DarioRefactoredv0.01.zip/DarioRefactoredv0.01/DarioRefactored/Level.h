#pragma once
#include "SDL.h"
#include "Scene.h"
#include "GameObject.h"
#include <vector>
using namespace std;


class Level : public Scene
{
private:
	vector<GameObject*> stuff;


public:
	virtual void Init();
	virtual void Render();
	virtual void Update();
	virtual void HandleEvents();
	virtual void Clean();

};


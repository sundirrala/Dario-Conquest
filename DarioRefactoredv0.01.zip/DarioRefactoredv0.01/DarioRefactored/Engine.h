#pragma once
#include "SDL.h"
class Engine
{
private:
	static Engine* iEngine;
	Engine();

	SDL_Window* pWindow = nullptr;
	SDL_Renderer* pRenderer = nullptr;

public:
	static Engine* GetEng();
	static SDL_Renderer* GetRen()
	{
		return iEngine->pRenderer;
	}
	void Init(){}


};


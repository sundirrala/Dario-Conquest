#include "TextureManager.h"
#include "Engine.h"

void TextureManager::Init()
{

	pSurface = IMG_Load("SOMETHING.png");
	vTexture.push_back(SDL_CreateTextureFromSurface(Engine::GetRen(), pSurface));
	SDL_FreeSurface(pSurface);

	//  These three lines get duplicated for each texture. Just change SOMETHING to the actual file name.
	//  There will be a lot of these. Like, maybe a billion. 



}

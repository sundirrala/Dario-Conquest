#pragma once
#ifndef __GAME__
#define __GAME__
#include "SDL.h"
class Game
{
public:

	static Game* Instance()
	{
		if(s_pInstance == 0)
		{ 
			s_pInstance = new Game();
			return s_pInstance;
		}
		return s_pInstance;
	}
	void init() { m_bRunning = true; }

	void render();
	void update();
	void handleEvents();
	void clean();
private:
	Game();
	~Game();
	
	SDL_Window* m_pWindow;
	SDL_Renderer* m_pRenderer;
	static Game* s_pInstance;
	bool m_bRunning;
};
typedef Game TheGame;

#endif // !__GAME__
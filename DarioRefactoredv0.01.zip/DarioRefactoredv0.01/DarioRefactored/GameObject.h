#pragma once

class GameObject
{

};


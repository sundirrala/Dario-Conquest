#pragma once

class State
{

};
#pragma once
class Scene
{
private:

public:





};


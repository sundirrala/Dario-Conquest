#pragma once
class StateMachine
{
};


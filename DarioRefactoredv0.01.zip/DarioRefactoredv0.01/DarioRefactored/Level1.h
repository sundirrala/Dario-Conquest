#pragma once
#include "Level.h"
class Level1 :
	public Level
{
};


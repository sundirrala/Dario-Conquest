#pragma once
#include "Level.h"
class Level2 :
	public Level
{
};


#include "SDL.h"
#include "SceneManager.h"
#include "Engine.h"
#include <iostream>

int main(int argc, char* args[])
{
	Engine::GetEng()->Init();




	std::cout << "I HATE PHOENIX!!!!";
	return 0;
}
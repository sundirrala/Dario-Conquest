#pragma once

class UIManager
{

};
#include "Game.h"


Game* Game::s_pInstance = 0;

void Game::render()
{
}

void Game::update()
{
}

void Game::handleEvents()
{
}

void Game::clean()
{
}

Game::Game()
{
}

Game::~Game()
{
}

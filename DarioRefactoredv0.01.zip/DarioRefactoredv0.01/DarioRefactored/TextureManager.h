#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include <vector>

using namespace std;

class TextureManager
{
private:
	vector<SDL_Texture*>vTexture;
	SDL_Surface* pSurface = nullptr;

public:
	void Init();
	SDL_Texture* GetTexture(int x)
	{
		return vTexture[x];
	}


};
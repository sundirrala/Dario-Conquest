#include "Engine.h"

Engine* Engine::iEngine;

Engine::Engine()
{
	pWindow = SDL_CreateWindow("Dario's Conquest (Phoenix sucks)", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024, 768, 0);
	pRenderer = SDL_CreateRenderer(pWindow, -1, 0);
}

Engine* Engine::GetEng()
{
	if (iEngine == nullptr)
	{
		iEngine = new Engine;
	}
	return iEngine;
}

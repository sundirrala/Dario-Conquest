#pragma once
#include "Level.h"
class Level3 :
	public Level
{
};


#pragma once

class MossBoss
{

};
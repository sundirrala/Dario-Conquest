#pragma once
#include "GameObject.h"
#include <cmath>

class Vine : public GameObject
{
private:
	int iteration = 0;
public:
	Vine(int x, int y)
	{
		rDst.x = x;
		rDst.y = y;
		ObjInit();
	}

	void Update()
	{
		iteration++;

		if(iteration == 361)
		{
			iteration = 0;
		}

		

		rDst.h = 240 + (10 * sin(iteration * M_PI / 180));
		rDst.y = 370 - (10 * sin(iteration * M_PI / 180));
	}
};


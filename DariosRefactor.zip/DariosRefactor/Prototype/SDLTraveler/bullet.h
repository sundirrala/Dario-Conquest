#pragma once
#include "SDL.h"


class Bullet
{
private:
	SDL_Rect source = { 0, 0, 16, 7 };
	SDL_Rect dest;

	int xVel = 15;

	SDL_RendererFlip flip = SDL_FLIP_NONE;

	bool edge;


public:

	Bullet(int x, int y, SDL_RendererFlip f)
	{
		dest.x = x;
		dest.y = y;
		dest.w = 16;
		dest.h = 7;

		edge = false;

		if (f == SDL_FLIP_HORIZONTAL)
		{
			flip = SDL_FLIP_HORIZONTAL;
			xVel *= -1;

		}
	}


	SDL_Rect getSrc()
	{
		return source;
	}
	SDL_Rect getDst()
	{
		return dest;
	}

	SDL_RendererFlip getFlip()
	{
		return flip;
	}

	void update()
	{
		dest.x += xVel;

		if (dest.x <= 0 || dest.x >= 1024)
		{
			edge = true;
		}

	}

	bool getEdge()
	{
		return edge;
	}

	int getX()
	{
		return dest.x;
	}
	int getY()
	{
		return dest.y;
	}

	~Bullet() {};


};

#pragma once
#include "SDL.h"


class Goomba
{
private:
	SDL_Rect source = { 0,0, 49, 67 };
	SDL_Rect dest = { 0,0, 49,67 };

	int frame = 0;
	int frameCount = 0;

	int direction = 1;

	SDL_RendererFlip flip = SDL_FLIP_NONE;

public:

	Goomba(int x, int y)
	{
		dest.x = x;
		dest.y = y;
	}

	void update()
	{
		frameCount++;
		dest.x += direction;
		if (frameCount % 2 == 0)
		{


			if (frame < 9)
			{
				frame++;
			}
			else
			{
				frame = 0;
			}
		}
		source.x = frame * 64;


		if (dest.x >= 980)
		{
			direction = -1;
		}

		if (dest.x <= 0)
		{
			direction = 1;
		}



	}
	int getX()
	{
		return dest.x;
	}
	int getY()
	{
		return dest.y;
	}

	SDL_RendererFlip getFlip()
	{
		return flip;
	}

	SDL_Rect getSrc()
	{
		return source;
	}

	SDL_Rect getDst()
	{
		return dest;
	}

};
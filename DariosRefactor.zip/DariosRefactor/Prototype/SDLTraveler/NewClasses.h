#pragma once
#include "SDL.h"
#include "SDL_mixer.h"

// Keybits thing
/*
const Uint8* keyStates;

bool KeyDown(SDL_Scancode c)
{
	if (keyStates != nullptr)
	{
		if (keyStates[c] == true)
		{
			return true;
		}
		else
			return false;
	}
	else
		return false;
}  

void handleEvents()
{
	if (KeyDown(SDL_SCANCODE_A))
	{

	}
	else if (KeyDown(SDL_SCANCODE_D))
	{

	}

	if (KeyDown(SDL_SCANCODE_E))
	{

	}

	if (KeyDown(SDL_SCANCODE_B))
	{

	}

	if (KeyDown(SDL_SCANCODE_J))
	{

	}

	if (KeyDown(SDL_SCANCODE_X))
	{

	}
}

*/



#pragma once
#include "bullet.h"
#include "Enemy.h"
#include "Platform.h"
#include "Player.h"
#include "Eyesplosion.h"
#include "Goomba.h"
#include "Goomblast.h"
#include "Health.h"
#include "Arrow.h"
#include "Eyebeam.h"

#include <iostream>
#include <fstream>
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_mixer.h"
#include "NewClasses.h"
#include "SDL_ttf.h"
#include <string>

using namespace std;

class Game
{
private:
	Player player;
	Bullet* bullet = nullptr;
	Enemy* eye = nullptr;
	Goomba* goom = nullptr;
	Eyesplosion* pop = nullptr;
	Goomblast* boom = nullptr;
	EyeBeam* beam = nullptr;

	Arrow arrow;

	int GoombaHP = 0;

	int popCount;
	int boomCount;

	SDL_Rect hpSR1 = { 32, 0, 22, 22 };
	SDL_Rect hpSR2 = { 32, 0, 50, 22 };
	SDL_Rect hpSR3 = { 32, 0, 80, 22 };

	SDL_Rect hpDR1 = { 64, 64, 44, 44 };
	SDL_Rect hpDR2 = { 64, 64, 100, 44 };
	SDL_Rect hpDR3 = { 64, 64, 160, 44 };


	SDL_Rect platformer = { 0, 0, 32, 37 };
	SDL_Rect i = { 0,0,0,0 };

	int grounded = 0;

	bool gameOn = true;

	// SDL stuff

	SDL_Window* pWindow = nullptr;
	SDL_Renderer* pRenderer = nullptr;
	SDL_Texture* pTexture = nullptr;
	SDL_Texture* eTexture = nullptr;
	SDL_Texture* gTexture = nullptr;
	SDL_Texture* bTexture = nullptr;
	SDL_Texture* goTexture = nullptr;
	SDL_Texture* lTexture = nullptr;

	SDL_Surface* pSurface = nullptr;



	Platform floor[12];



	const char* num;
	int iNum = 0;
	string newNum;

	const char* num2;
	int iNum2 = 0;
	string newNum2;


	TTF_Font* font1 = nullptr;
	SDL_Color white = { 0,0,0 };
	SDL_Surface* tSurface = nullptr;
	SDL_Texture* tTexture = nullptr;
	SDL_Texture* tTexture2 = nullptr;

	//string numberText;

	SDL_Rect textR = { 500, 40 ,100,50 };
	SDL_Rect textR2 = { 390,50,100, 25 };


	SDL_GameController* controller1 = nullptr;
	SDL_Event event;
	SDL_RendererFlip flip = SDL_FLIP_NONE;


	Mix_Music* sMusic = nullptr;

	Mix_Chunk* sJump = nullptr;
	Mix_Chunk* sFire = nullptr;
	Mix_Chunk* sPlat = nullptr;
	Mix_Chunk* sBoom = nullptr;
	Mix_Chunk* sCrackle = nullptr;
	Mix_Chunk* sSlash = nullptr;


public:
	Game();

	void Init();

	void HandleEvents();

	void Update();

	void Render();

	void Clean();

	bool Over();

	void Reset();

	bool endGame()
	{
		if (gameOn == true)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	~Game();
};


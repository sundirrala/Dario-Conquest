#pragma once
#include "SDL.h"




class Enemy
{
private:
	//int hp;
	//int maxHp;

	double xVel = 0;
	double yVel = 0;


	SDL_Rect source;
	SDL_Rect dest;

	SDL_RendererFlip flip = SDL_FLIP_NONE;

public:

	Enemy()
	{
		source = { 192, 96, 44, 44 };
		dest = { 512 ,0, 44, 44 };
	}

	void update(int x, int y)
	{
		dest.x += xVel;
		dest.y += yVel;


		if (x > dest.x)
		{
			xVel = 1;
			flip = SDL_FLIP_HORIZONTAL;
		}
		else if (x < dest.x)
		{
			xVel = -1;
			flip = SDL_FLIP_NONE;
		}
		else
		{
			xVel = 0;
		}

		if (y - 10 > dest.y)
		{
			yVel = 1;
		}
		else if (y - 10 < dest.y)
		{
			yVel = -1;
		}
		else
		{
			yVel = 0;
		}
	}

	SDL_Rect getSrc()
	{
		return source;
	}
	SDL_Rect getDst()
	{
		return dest;
	}

	SDL_RendererFlip getFlip()
	{
		return flip;
	}

	int getX()
	{
		return dest.x;
	}
	int getY()
	{
		return dest.y;
	}


};

#include "Bartender.h"

void Bartender::Update()
{
	cycle++;
	if (cycle % 4 == 0) {
		iteration++;
		rSrc.x = 70 * (iteration % 20);
	}
}

void Bartender::Render(SDL_Renderer* pRend)
{
	SDL_RenderCopy(pRend, BartenderTexture, &rSrc, &rDst);
}

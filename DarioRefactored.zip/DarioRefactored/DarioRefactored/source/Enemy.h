#pragma once
class Enemy
{

};
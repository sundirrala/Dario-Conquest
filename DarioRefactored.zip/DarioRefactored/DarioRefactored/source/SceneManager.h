#pragma once
class SceneManager
{
};


#pragma once

class Platforms
{

};
#pragma once

class GameObject
{

};
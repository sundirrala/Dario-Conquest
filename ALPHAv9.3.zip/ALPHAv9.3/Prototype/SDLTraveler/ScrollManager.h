#pragma once
class ScrollManager
{
private:
	static ScrollManager* Scroller;
	ScrollManager();

	int offSetX = 0;
	int offSetY = 0;

	int limitLeft = 400;
	int limitRight = 0;

public:
	static ScrollManager* GetScroll();
	void Reset()
	{
		offSetX = 0;
	}

	int OffX()
	{
		return offSetX;
	}

	void SetLimits(int l)
	{
		limitRight = l - 400;
	}

	int GetLimitL()
	{
		return limitLeft;
	}

	int GetLimitR()
	{
		return limitRight;
	}

	int OffY()
	{
		return offSetY;
	}

	void Scroll(int x)
	{
		offSetX += x;
	}

	~ScrollManager();
};


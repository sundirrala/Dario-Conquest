#include "AudioManager.h"

AudioManager* AudioManager::AudioMan;

AudioManager::AudioManager()
{
	Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 4096);
	Mix_AllocateChannels(16);

	sMusic = Mix_LoadMUS("Dario-SongBG_1.wav");
	sCombat = Mix_LoadMUS("Combat.wav");
	sForest = Mix_LoadMUS("Forest.wav");
	sAlien = Mix_LoadMUS("Alien.wav");
	sDeath = Mix_LoadMUS("Continue.wav");
	sCredits = Mix_LoadMUS("Credits.wav");
	sPause = Mix_LoadMUS("Pause.wav");
	sClang = Mix_LoadWAV("Clang.wav");
	sBurn = Mix_LoadWAV("Sizzle.wav");
	sPunch = Mix_LoadWAV("Punch.wav");
	sLaser = Mix_LoadWAV("Laser.wav");
	sJump = Mix_LoadWAV("jump.wav");
	sFire = Mix_LoadWAV("fire.wav");
	sFire2 = Mix_LoadWAV("Gun.wav");
	sfire3 = Mix_LoadWAV("fiee.wav");
	sPlat = Mix_LoadWAV("splat.wav");
	sBoom = Mix_LoadWAV("boom.wav");
	sCrackle = Mix_LoadWAV("buzz.wav");
	sSlash = Mix_LoadWAV("Slash.wav");
	sSlash2 = Mix_LoadWAV("Slash2.wav");

	Mix_VolumeMusic(25);
	Mix_Volume(-1, 128);	

}

AudioManager* AudioManager::GetInstance()
{
	if (AudioMan == nullptr)
	{
		AudioMan = new AudioManager;

	}
	return AudioMan;
}

void AudioManager::Music1()
{
	Mix_PlayMusic(sMusic, -1);
}
void AudioManager::Music2()
{
	Mix_PlayMusic(sCombat, -1);
}
void AudioManager::Alien()
{
	Mix_PlayMusic(sAlien, -1);
}
void AudioManager::Forest()
{
	Mix_PlayMusic(sForest, -1);
}
void AudioManager::Death()
{
	Mix_PlayMusic(sDeath, -1);
}
void AudioManager::Credits()
{
	Mix_PlayMusic(sCredits, -1);
}
void AudioManager::Pause()
{
	Mix_PlayMusic(sPause, -1);
}
void AudioManager::Jump()
{
	Mix_PlayChannel(3, sJump, 0);
}
void AudioManager::Fire()
{
	Mix_PlayChannel(1, sFire, 0);
}

void AudioManager::Fire2()
{
	Mix_PlayChannel(6, sFire2, 0);
}

void AudioManager::Fire3()
{
	Mix_PlayChannel(7, sfire3, 0);
}

void AudioManager::Laser()
{
	Mix_PlayChannel(8, sLaser, 0);
}

void AudioManager::Burn()
{
	Mix_PlayChannel(10, sBurn, 0);
}

void AudioManager::Clang()
{
	Mix_PlayChannel(11, sClang, 0);
}

void AudioManager::Splat()
{
	Mix_PlayChannel(5, sPlat, 0);
}
void AudioManager::Boom()
{
	Mix_PlayChannel(2, sBoom, 0);

}
void AudioManager::Punch()
{
	Mix_PlayChannel(9, sPunch, 0);
}
void AudioManager::Crackle()
{
	Mix_PlayChannel(4, sCrackle, 0);
}
void AudioManager::Slash()
{
	Mix_PlayChannel(1, sSlash, 0);
}

void AudioManager::Slash2()
{
	Mix_PlayChannel(12, sSlash2, 0);
}

AudioManager::~AudioManager()
{
}

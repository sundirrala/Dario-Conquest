#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "GameObject.h"

class Bartender : public GameObject
{
public:
	int iteration = 0, cycle = 0;
	SDL_Texture* BartenderTexture;
	Bartender(SDL_Renderer* pRend)
	{
		rSrc = { 0,0, 70, 87 };
		rDst = { 450 - (70 + 200) , 450 - (87 + 80), 140 + 50, 174 + 50 };
		BartenderTexture = IMG_LoadTexture(pRend, "bartenderlu.png");
	}
	void Update();
	void Render(SDL_Renderer* pRend);
};
#include "Bartender.h"

void Bartender::Update()
{
	cycle++;
	if (cycle % 10 == 0) {
		iteration++;
		rSrc.x = 70 * (iteration % 4);
	}
}

void Bartender::Render(SDL_Renderer* pRend)
{
	SDL_RenderCopy(pRend, BartenderTexture, &rSrc, &rDst);
}

#pragma once
#include "GameObject.h"
#include "SDL.h"
#include "SDL_image.h"
#include <iostream>

enum TypeOfBeer
{
	REGULAR_BEER, // +1 hp
	IRON_BEER, // +1 Hp
	CONFUSION_BEER, // Reverse controls
	POISON_BEER, // -1 hp
	STRENGTH_BEER, // bigger bullets
	SLOW_BEER // makes dario slower?
};

class Beer: public GameObject
{
public:
	Beer(SDL_Renderer* p) {
		BeerSurf = IMG_Load("Beer.png");
		if (BeerSurf == NULL)
			std::cout << "SURFACE FAIL \n\n";
		BeerTexture = SDL_CreateTextureFromSurface(p, BeerSurf);
		if (BeerTexture == NULL)
		{
			std::cout << "TEXTURE FAIL \n\n";
			std::cout << IMG_GetError;
		}
		SDL_FreeSurface(BeerSurf);

		rSrc = { 0, 0, 32, 32 };
		rDst = { 480, 530, 64, 64 };


		ObjInit();

	}
	
	SDL_Rect GetDst()
	{
		return rDst;
	}
	void SetDst(int x, int y)
	{
		rDst.x = x;
		rDst.y = y;
		ObjInit();
	}

	void Render(SDL_Renderer* p);
	
	void Update();

	~Beer(){}
	
private:
	int iteration = 0, cycle = 0;// Animation Loop counter 
	bool animation = false;
	SDL_Surface* BeerSurf = nullptr;
	SDL_Texture* BeerTexture = nullptr;
	SDL_Renderer* p;
	TypeOfBeer ToB;

	TypeOfBeer GetType() { return ToB; }
	void SetBeer(TypeOfBeer beer) { ToB = beer; }
};

